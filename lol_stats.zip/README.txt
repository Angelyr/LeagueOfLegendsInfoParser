HOMEWORK 2: LEAGUE OF LEGENDS CLASSES


NAME:  < Angel Castillo >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< http://www.cplusplus.com/ , TA during lab >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 9 >



DESCRIPTION OF 3RD STATISTIC: 
Please be clear & concise!  What is your hypothesis for the creation
of this statistic?

My new statistics shows the amount of assists, largest amount of kills before dying,
and highest amount of deaths before getting a kill. I expect that the higher the kill
death ratio the higher the killing spree will be and the lower the death spree. Also I 
expect that the higher the assists the lower the deaths.

RESULTS FROM 3RD STATISTIC:
Paste in a small amount of sample output into this file, or list the
file names of sample input & output included with your submisssion.
Describe what is interesting about your statistic on this data.
Please be concise!

CHAMPION NAME        KILLS     DEATHS    ASSISTS   KILLING SPREE     DEATH SPREE    
Amumu                6         1         21        6                 0              
Blitzcrank           4         3         16        2                 0              
Brand                7         2         10        2                 0              
Graves               19        16        17        3                 5              
LeBlanc              10        12        10        4                 6              
Lissandra            6         7         12        6                 4              
Sejuani              10        3         22        4                 2              
Tristana             13        6         10        7                 5              
Zac                  3         1         10        2                 1              
Fizz                 5         10        4         2                 4              
Kalista              6         8         3         6                 0              
Nasus                7         8         4         3                 3              
Riven                6         8         4         3                 5              
Syndra               6         7         5         2                 2              
Taric                0         7         14        0                 0              
Thresh               5         9         31        3                 1              
Udyr                 1         3         7         1                 0              
Warwick              4         9         7         3                 5              

What I found interesing is the that champions with more kills tend to also
have more assists. I also find it interesting that having a high amount of
kills doesn't meant you have a high killing spree. 

MISC. COMMENTS TO GRADER:  
Optional, please be concise!

Input of 100 takes 20-30 seconds to run.

